import 'dart:async';
import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';

// --- Model de Date: Produs ---
class Produs {
  String? id;
  String nume;
  String codBare;
  String codCasa;
  double pret;

  Produs({
    this.id,
    required this.nume,
    required this.codBare,
    required this.codCasa,
    required this.pret,
  });

  // Metodele toMap și fromFirestore nu mai sunt necesare fără Firestore
  Map<String, dynamic> toMap() {
    return {
      'nume': nume,
      'codBare': codBare,
      'codCasa': codCasa,
      'pret': pret,
    };
  }
}

// --- Serviciu Simplificat pentru Produse (fără Firestore) ---
// Vom simula stocarea produselor într-o listă locală.
class ProdusServiceLocal {
  final List<Produs> _produse = [
    Produs(id: '1', nume: 'Paine Alba', codBare: '1234567890123', codCasa: '101', pret: 3.50),
    Produs(id: '2', nume: 'Lapte 1.5L', codBare: '9876543210987', codCasa: '102', pret: 6.00),
    Produs(id: '3', nume: 'Oua (10 buc)', codBare: '5432109876543', codCasa: '103', pret: 12.00),
    Produs(id: '4', nume: 'Ciocolata Milka', codBare: '1122334455667', codCasa: '104', pret: 4.75),
  ];

  // Simulează salvarea/actualizarea unui produs
  Future<void> salveazaProdus(Produs produs) async {
    if (produs.id == null) {
      produs.id = DateTime.now().millisecondsSinceEpoch.toString(); // ID unic
      _produse.add(produs);
    } else {
      final index = _produse.indexWhere((p) => p.id == produs.id);
      if (index != -1) {
        _produse[index] = produs;
      }
    }
    // Simulează o mică întârziere
    await Future.delayed(const Duration(milliseconds: 300));
  }

  // Simulează obținerea produselor (fără Stream, doar Future)
  Future<List<Produs>> getProduse({String? query}) async {
    await Future.delayed(const Duration(milliseconds: 200)); // Simulează întârziere
    if (query != null && query.isNotEmpty) {
      return _produse.where((p) => p.nume.toLowerCase().contains(query.toLowerCase())).toList();
    }
    return List.from(_produse); // Returnează o copie pentru a evita modificări externe
  }

  // Simulează obținerea unui produs după cod de bare
  Future<Produs?> getProdusByCodBare(String codBare) async {
    await Future.delayed(const Duration(milliseconds: 100)); // Simulează întârziere
    return _produse.firstWhereOrNull((p) => p.codBare == codBare);
  }

  // Simulează ștergerea unui produs
  Future<void> stergeProdus(String id) async {
    _produse.removeWhere((p) => p.id == id);
    await Future.delayed(const Duration(milliseconds: 300));
  }
}

// Extensie pentru firstWhereOrNull, deoarece nu mai folosim pachetul collection
extension ListExtension<T> on List<T> {
  T? firstWhereOrNull(bool Function(T element) test) {
    for (var element in this) {
      if (test(element)) {
        return element;
      }
    }
    return null;
  }
}


// --- Serviciu Simplificat pentru Vanzari (fără Firestore) ---
// Vom simula stocarea vânzărilor într-o listă locală.
class VanzareServiceLocal {
  final List<Map<String, dynamic>> _vanzari = [];

  Future<void> adaugaVanzare(List<Produs> bon, double total, String metodaPlata) async {
    final vanzareId = DateTime.now().millisecondsSinceEpoch.toString();
    _vanzari.add({
      'id': vanzareId,
      'timestamp': DateTime.now(),
      'total': total,
      'metodaPlata': metodaPlata,
      'items': bon.map((p) => p.toMap()).toList(),
    });
    await Future.delayed(const Duration(milliseconds: 300));
  }

  Future<List<Map<String, dynamic>>> getVanzari(DateTime dataSelectata) async {
    await Future.delayed(const Duration(milliseconds: 200));
    return _vanzari.where((v) {
      final timestamp = v['timestamp'] as DateTime;
      return timestamp.year == dataSelectata.year &&
             timestamp.month == dataSelectata.month &&
             timestamp.day == dataSelectata.day;
    }).toList();
  }

  Future<List<Map<String, dynamic>>> getDetaliiVanzare(String vanzareId) async {
    await Future.delayed(const Duration(milliseconds: 100));
    final vanzare = _vanzari.firstWhereOrNull((v) => v['id'] == vanzareId);
    return (vanzare?['items'] as List<dynamic>?)?.cast<Map<String, dynamic>>() ?? [];
  }
}


// --- Functia Main ---
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const CasaDeMarcatApp());
}

class CasaDeMarcatApp extends StatefulWidget {
  const CasaDeMarcatApp({super.key});

  @override
  State<CasaDeMarcatApp> createState() => _CasaDeMarcatAppState();
}

class _CasaDeMarcatAppState extends State<CasaDeMarcatApp> {
  // Nu mai este nevoie de _initialization Firebase
  @override
  Widget build(BuildContext context) {
    initializeDateFormatting('ro_RO', null); // Mutat aici, nu mai este în FutureBuilder
    return MaterialApp(
      title: 'Casă de Marcat',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
        useMaterial3: true,
      ),
      home: const PaginaPrincipala(), // Mergem direct la PaginaPrincipala, fără AuthGate
      debugShowCheckedModeBanner: false,
    );
  }
}

// --- Pagina Principala cu Navigare (fără autentificare) ---
class PaginaPrincipala extends StatefulWidget {
  const PaginaPrincipala({super.key});
  @override
  State<PaginaPrincipala> createState() => _PaginaPrincipalaState();
}
class _PaginaPrincipalaState extends State<PaginaPrincipala> {
  int _selectedIndex = 0;
  final List<Widget> _pagini = [
    const PaginaCasa(),
    PaginaInventar(),
    const PaginaVanzari(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Casă de Marcat (Offline)'), // Titlu simplificat
        // Nu mai este nevoie de acțiuni de logout
      ),
      body: IndexedStack(index: _selectedIndex, children: _pagini),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(icon: Icon(Icons.point_of_sale), label: 'Casă'),
          BottomNavigationBarItem(icon: Icon(Icons.inventory), label: 'Inventar'),
          BottomNavigationBarItem(icon: Icon(Icons.receipt_long), label: 'Vânzări'),
        ],
        currentIndex: _selectedIndex,
        onTap: (index) => setState(() => _selectedIndex = index),
      ),
    );
  }
}

// --- Pagina "Casă" ---
class PaginaCasa extends StatefulWidget {
  const PaginaCasa({super.key});
  @override
  State<PaginaCasa> createState() => _PaginaCasaState();
}
class _PaginaCasaState extends State<PaginaCasa> {
  final List<Produs> _bonCurent = [];
  double _totalBon = 0.0;
  final AudioPlayer _audioPlayer = AudioPlayer();
  final MobileScannerController _cameraController = MobileScannerController();
  final ProdusServiceLocal _produsService = ProdusServiceLocal(); // Folosim serviciul local
  final VanzareServiceLocal _vanzareService = VanzareServiceLocal(); // Folosim serviciul local

  void _onBarcodeDetected(BarcodeCapture capture) async {
    final String codScanat = capture.barcodes.first.rawValue ?? "";
    if (codScanat.isEmpty) return;

    _cameraController.stop();
    Produs? produs = await _produsService.getProdusByCodBare(codScanat); // Folosim serviciul local

    if (!mounted) return;
    if (produs != null) {
      setState(() {
        _bonCurent.add(produs);
        _calculeazaTotal();
      });
      await _audioPlayer.play(AssetSource('sounds/beep.mp3'), volume: 1.0);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Produsul cu codul $codScanat nu a fost găsit.'), backgroundColor: Colors.red));
    }
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) _cameraController.start();
    });
  }

  void _calculeazaTotal() => setState(() => _totalBon = _bonCurent.fold(0.0, (sum, item) => sum + item.pret));
  
  void _showMetodaPlataDialog() {
    if (_bonCurent.isEmpty) return;
    showDialog(context: context, builder: (context) => AlertDialog(
      title: const Text('Alege metoda de plată'),
      actions: [
        TextButton(onPressed: () => _finalizareVanzare('Cash'), child: const Text('Cash')),
        TextButton(onPressed: () => _finalizareVanzare('Card'), child: const Text('Card')),
      ],
    ));
  }

  void _finalizareVanzare(String metodaPlata) async {
    Navigator.of(context).pop(); // Inchide dialogul
    await _vanzareService.adaugaVanzare(_bonCurent, _totalBon, metodaPlata); // Folosim serviciul local
    if (!mounted) return;
    setState(() {
      _bonCurent.clear();
      _calculeazaTotal();
    });
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Vânzare finalizată!'), backgroundColor: Colors.blue));
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Partea de sus: Camera
        SizedBox(
          height: 200,
          child: MobileScanner(
            controller: _cameraController,
            onDetect: _onBarcodeDetected,
          ),
        ),
        // Partea de mijloc: Lista de produse, care umple spatiul disponibil
        Expanded(
          child: _bonCurent.isEmpty
              ? const Center(
                  child: Text('Scanează un produs pentru a începe.'),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(8.0),
                  itemCount: _bonCurent.length,
                  itemBuilder: (context, index) => Card(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    child: ListTile(
                      title: Text(_bonCurent[index].nume),
                      trailing: Text('${_bonCurent[index].pret.toStringAsFixed(2)} RON'),
                      onLongPress: () => setState(() {
                        _bonCurent.removeAt(index);
                        _calculeazaTotal();
                      }),
                    ),
                  ),
                ),
        ),
        // Partea de jos: Totalul si butonul, mereu vizibile
        Container(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 32), // Spatiu mai mare jos
          decoration: BoxDecoration(
            color: Theme.of(context).scaffoldBackgroundColor,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                spreadRadius: 1,
                blurRadius: 5,
                offset: const Offset(0, -3),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('TOTAL:', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  Text('${_totalBon.toStringAsFixed(2)} RON', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.teal)),
                ],
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
                  onPressed: _showMetodaPlataDialog,
                  child: const Text('Finalizează Vânzarea'),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  @override
  void dispose() {
    _cameraController.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }
}

// --- Pagina "Inventar" ---
class PaginaInventar extends StatefulWidget {
  @override
  _PaginaInventarState createState() => _PaginaInventarState();
}
class _PaginaInventarState extends State<PaginaInventar> {
  final ProdusServiceLocal _produsService = ProdusServiceLocal(); // Folosim serviciul local
  final TextEditingController _searchController = TextEditingController();
  List<Produs> _produseAfisate = [];

  @override
  void initState() {
    super.initState();
    _incarcaProduse();
    _searchController.addListener(_incarcaProduse);
  }

  void _incarcaProduse() async {
    final produse = await _produsService.getProduse(query: _searchController.text);
    setState(() {
      _produseAfisate = produse;
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _showProdusDialog(BuildContext context, {Produs? produs}) {
    final formKey = GlobalKey<FormState>();
    final numeController = TextEditingController(text: produs?.nume ?? '');
    final codBareController = TextEditingController(text: produs?.codBare ?? '');
    final codCasaController = TextEditingController(text: produs?.codCasa ?? '');
    final pretController = TextEditingController(text: (produs?.pret.toString() ?? '').replaceAll('.', ','));

    showDialog(context: context, builder: (dialogContext) => AlertDialog(
      title: Text(produs == null ? 'Adaugă Produs' : 'Editează Produs'),
      content: Form(
        key: formKey,
        child: SingleChildScrollView(child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextFormField(controller: numeController, decoration: const InputDecoration(labelText: 'Nume Produs'), validator: (v) => v!.isEmpty ? 'Câmp obligatoriu' : null),
            TextFormField(
              controller: codBareController,
              decoration: InputDecoration(
                labelText: 'Cod de Bare',
                suffixIcon: IconButton(
                  icon: const Icon(Icons.camera_alt),
                  onPressed: () async {
                    final codScanat = await Navigator.push<String>(context, MaterialPageRoute(builder: (_) => const BarcodeScannerPage()));
                    if (codScanat != null) codBareController.text = codScanat;
                  },
                ),
              ),
              validator: (v) => v!.isEmpty ? 'Câmp obligatoriu' : null,
            ),
            TextFormField(controller: codCasaController, decoration: const InputDecoration(labelText: 'Cod pe Casă')),
            TextFormField(controller: pretController, decoration: const InputDecoration(labelText: 'Preț'), keyboardType: const TextInputType.numberWithOptions(decimal: true), validator: (v) => v!.isEmpty ? 'Câmp obligatoriu' : null),
          ],
        )),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Anulează')),
        ElevatedButton(
          onPressed: () async {
            if (formKey.currentState!.validate()) {
              final p = Produs(
                id: produs?.id,
                nume: numeController.text,
                codBare: codBareController.text,
                codCasa: codCasaController.text,
                pret: double.tryParse(pretController.text.replaceAll(',', '.')) ?? 0.0,
              );
              await _produsService.salveazaProdus(p); // Folosim serviciul local
              if(mounted) Navigator.pop(dialogContext);
              _incarcaProduse(); // Reîmprospătăm lista
            }
          },
          child: const Text('Salvează'),
        )
      ],
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Inventar (Offline)'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(kToolbarHeight),
          child: Padding(
            padding: const EdgeInsets.all(8.0), 
            child: TextField(
              controller: _searchController, 
              decoration: InputDecoration(labelText: 'Caută după nume', prefixIcon: const Icon(Icons.search), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12))),
              // onChanged este gestionat de addListener în initState
            )
          ),
        ),
      ),
      body: _produseAfisate.isEmpty
          ? const Center(child: Text('Nu există produse în inventar.'))
          : ListView.builder(
              itemCount: _produseAfisate.length,
              itemBuilder: (context, index) {
                final produs = _produseAfisate[index];
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  child: ListTile(
                    title: Text(produs.nume),
                    subtitle: Text('Cod: ${produs.codBare} | Preț: ${produs.pret.toStringAsFixed(2)} RON'),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      IconButton(icon: const Icon(Icons.edit, color: Colors.blue), onPressed: () => _showProdusDialog(context, produs: produs)),
                      IconButton(icon: const Icon(Icons.delete, color: Colors.red), onPressed: () async {
                        await _produsService.stergeProdus(produs.id!); // Folosim serviciul local
                        _incarcaProduse(); // Reîmprospătăm lista
                      }),
                    ]),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(onPressed: () => _showProdusDialog(context), child: const Icon(Icons.add)),
    );
  }
}

// --- Pagina "Vânzări" ---
class PaginaVanzari extends StatefulWidget {
  const PaginaVanzari({super.key});
  @override
  State<PaginaVanzari> createState() => _PaginaVanzariState();
}
class _PaginaVanzariState extends State<PaginaVanzari> {
  DateTime _dataSelectata = DateTime.now();
  final VanzareServiceLocal _vanzareService = VanzareServiceLocal(); // Folosim serviciul local
  List<Map<String, dynamic>> _vanzariAfisate = [];

  @override
  void initState() {
    super.initState();
    _incarcaVanzari();
  }

  @override
  void didUpdateWidget(covariant PaginaVanzari oldWidget) {
    super.didUpdateWidget(oldWidget);
    _incarcaVanzari(); // Reîmprospătăm dacă widget-ul se actualizează
  }

  void _incarcaVanzari() async {
    final vanzari = await _vanzareService.getVanzari(_dataSelectata);
    setState(() {
      _vanzariAfisate = vanzari;
    });
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(context: context, initialDate: _dataSelectata, firstDate: DateTime(2020), lastDate: DateTime.now());
    if (picked != null && picked != _dataSelectata) {
      setState(() => _dataSelectata = picked);
      _incarcaVanzari(); // Reîmprospătăm vânzările pentru data nouă
    }
  }

  @override
  Widget build(BuildContext context) {
    double totalZi = _vanzariAfisate.fold(0.0, (sum, doc) => sum + (doc['total'] as num));

    return Scaffold(
      appBar: AppBar(
        title: Text('Vânzări (Offline) - ${DateFormat.yMMMMd('ro_RO').format(_dataSelectata)}'),
        actions: [IconButton(icon: const Icon(Icons.calendar_today), onPressed: () => _selectDate(context))],
      ),
      body: Column(
        children: [
          Padding(padding: const EdgeInsets.all(16.0), child: Text('Total Zi: ${totalZi.toStringAsFixed(2)} RON', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.green))),
          Expanded(child: _vanzariAfisate.isEmpty
              ? const Center(child: Text("Nu există vânzări pentru data selectată."))
              : ListView.builder(
                  itemCount: _vanzariAfisate.length,
                  itemBuilder: (context, index) {
                    final vanzare = _vanzariAfisate[index];
                    final timestamp = vanzare['timestamp'] as DateTime;
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      child: ListTile(
                        title: Text('Vânzare la ${DateFormat.Hm('ro_RO').format(timestamp)} (${vanzare['metodaPlata']})'),
                        subtitle: Text('Total: ${vanzare['total'].toStringAsFixed(2)} RON'),
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PaginaDetaliiVanzare(vanzareId: vanzare['id'] as String, vanzareService: _vanzareService))),
                      ),
                    );
                  },
                )),
        ],
      ),
    );
  }
}

// --- Pagina "Detalii Vanzare" ---
class PaginaDetaliiVanzare extends StatefulWidget {
  final String vanzareId;
  final VanzareServiceLocal vanzareService;
  PaginaDetaliiVanzare({super.key, required this.vanzareId, required this.vanzareService});

  @override
  State<PaginaDetaliiVanzare> createState() => _PaginaDetaliiVanzareState();
}

class _PaginaDetaliiVanzareState extends State<PaginaDetaliiVanzare> {
  List<Map<String, dynamic>> _items = [];

  @override
  void initState() {
    super.initState();
    _incarcaDetalii();
  }

  void _incarcaDetalii() async {
    final items = await widget.vanzareService.getDetaliiVanzare(widget.vanzareId);
    setState(() {
      _items = items;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Detalii Vânzare (Offline)')),
      body: _items.isEmpty
          ? const Center(child: CircularProgressIndicator()) // Sau un mesaj "Nu s-au găsit detalii"
          : ListView.builder(
              itemCount: _items.length,
              itemBuilder: (context, index) {
                final item = _items[index];
                return ListTile(
                  title: Text(item['nume'] ?? 'Produs șters'),
                  trailing: Text('${(item['pret'] as num).toStringAsFixed(2)} RON'),
                );
              },
            ),
    );
  }
}

// --- Pagina simpla pentru scanare ---
class BarcodeScannerPage extends StatelessWidget {
  const BarcodeScannerPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Scanează Codul de Bare')),
      body: MobileScanner(
        onDetect: (capture) {
          final String? code = capture.barcodes.first.rawValue;
          if (code != null) {
            Navigator.pop(context, code);
          }
        },
      ),
    );
  }
}
