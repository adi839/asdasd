// Aplică plugin-urile necesare pentru modulul aplicației.
plugins {
    id("com.android.application")
    id("kotlin-android")
    id("dev.flutter.flutter-gradle-plugin")
    // Am eliminat: id("com.google.gms.google-services")
}

// Configurația specifică Android pentru modulul aplicației.
android {
    namespace = "com.example.test_app_nou" # Numele pachetului tău. Asigură-te că este corect.
    compileSdk = 35 # Lăsăm la 35, cum am stabilit anterior

    defaultConfig {
        applicationId = "com.example.test_app_nou" # ID-ul aplicației tale. Asigură-te că este corect.
        minSdk = 23 # Lăsăm la 23
        targetSdk = 35 # Lăsăm la 35
        versionCode = 1
        versionName = "1.0"
        multiDexEnabled = true # Activează multidex (poate fi necesar chiar și fără Firebase)
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = "1.8"
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("debug")
        }
    }
}

flutter {
    source = "../.."
}

dependencies {
    // Am eliminat toate dependențele Firebase
    // Am păstrat multidex, deoarece poate fi util
    implementation("androidx.multidex:multidex:2.0.1")
}
